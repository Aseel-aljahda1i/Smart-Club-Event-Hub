CREATE TABLE IF NOT EXISTS clubs(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  club_id INTEGER NOT NULL REFERENCES clubs(id),
  title TEXT NOT NULL, description TEXT, location TEXT,
  starts_at TEXT NOT NULL, capacity INTEGER NOT NULL DEFAULT 100);
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  university_id TEXT NOT NULL UNIQUE, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS registrations(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id INTEGER NOT NULL REFERENCES events(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  token TEXT NOT NULL UNIQUE,
  attended_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(event_id, student_id));
CREATE INDEX IF NOT EXISTS ix_reg_event ON registrations(event_id);

INSERT OR IGNORE INTO clubs(id,name) VALUES
 (1,'نادي البرمجة'),(2,'نادي الذكاء الاصطناعي'),(3,'نادي ريادة الأعمال');
INSERT OR IGNORE INTO events(id,club_id,title,description,location,starts_at,capacity) VALUES
 (1,1,'ورشة تطوير تطبيقات الويب','أساسيات بناء واجهة وخدمة خلفية في ساعتين.','قاعة 204 - كلية الحاسب',datetime('now','+5 day','+10 hour'),40),
 (2,2,'ملتقى الذكاء الاصطناعي التوليدي','عروض قصيرة وتجارب مباشرة مع الأدوات الحديثة.','المسرح الرئيسي',datetime('now','+9 day','+12 hour'),150),
 (3,3,'ليلة عرض الأفكار الناشئة','يعرض الطلاب أفكارهم أمام لجنة من رواد الأعمال.','مركز الابتكار',datetime('now','+14 day','+16 hour'),60);
