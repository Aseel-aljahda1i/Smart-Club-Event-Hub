using Microsoft.Data.Sqlite;

var app = WebApplication.CreateBuilder(args).Build();
var cs = "Data Source=hub.db";
// بدون رمز افتراضيًا. لتفعيل الرمز عيّن المتغير ORGANIZER_CODE
var orgCode = Environment.GetEnvironmentVariable("ORGANIZER_CODE");

List<Dictionary<string, object?>> Q(string sql, params (string k, object? v)[] p)
{
    using var c = new SqliteConnection(cs); c.Open();
    using var m = c.CreateCommand(); m.CommandText = sql;
    foreach (var (k, v) in p) m.Parameters.AddWithValue(k, v ?? DBNull.Value);
    using var r = m.ExecuteReader();
    var list = new List<Dictionary<string, object?>>();
    while (r.Read())
    {
        var d = new Dictionary<string, object?>();
        for (int i = 0; i < r.FieldCount; i++) d[r.GetName(i)] = r.IsDBNull(i) ? null : r.GetValue(i);
        list.Add(d);
    }
    return list;
}
void X(string sql, params (string k, object? v)[] p)
{
    using var c = new SqliteConnection(cs); c.Open();
    using var m = c.CreateCommand(); m.CommandText = sql;
    foreach (var (k, v) in p) m.Parameters.AddWithValue(k, v ?? DBNull.Value);
    m.ExecuteNonQuery();
}
bool Org(HttpRequest q) => string.IsNullOrEmpty(orgCode) || q.Headers["X-Code"] == orgCode;

X(File.ReadAllText(Path.Combine(app.Environment.ContentRootPath, "schema.sql")));
app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (Exception ex) when (ctx.Request.Path.StartsWithSegments("/api"))
    {
        Console.WriteLine(ex);
        ctx.Response.StatusCode = 500;
        await ctx.Response.WriteAsJsonAsync(new { error = "خطأ في الخادم: " + ex.Message });
    }
});
app.UseDefaultFiles(); app.UseStaticFiles();

// ---------- الطالب (بدون كلمة مرور) ----------
app.MapGet("/api/events", () => Q(@"SELECT e.id,e.title,e.description,e.location,e.starts_at,e.capacity,c.name club,
  (SELECT COUNT(*) FROM registrations WHERE event_id=e.id) registered
  FROM events e JOIN clubs c ON c.id=e.club_id ORDER BY e.starts_at"));

app.MapPost("/api/events/{id:int}/register", IResult (int id, Reg r) =>
{
    if (string.IsNullOrWhiteSpace(r.universityId) || string.IsNullOrWhiteSpace(r.name))
        return Results.BadRequest(new { error = "أدخل الاسم والرقم الجامعي" });
    var ev = Q("SELECT capacity,(SELECT COUNT(*) FROM registrations WHERE event_id=@e) n FROM events WHERE id=@e", ("@e", id));
    if (ev.Count == 0) return Results.NotFound(new { error = "الفعالية غير موجودة" });
    if ((long)ev[0]["n"]! >= (long)ev[0]["capacity"]!) return Results.BadRequest(new { error = "اكتمل العدد" });
    var u = r.universityId.Trim();
    X("INSERT INTO students(university_id,name) VALUES(@u,@n) ON CONFLICT(university_id) DO UPDATE SET name=@n", ("@u", u), ("@n", r.name.Trim()));
    X(@"INSERT OR IGNORE INTO registrations(event_id,student_id,token)
        SELECT @e,id,@t FROM students WHERE university_id=@u",
      ("@e", id), ("@u", u), ("@t", Guid.NewGuid().ToString("N")[..12].ToUpper()));
    var row = Q("SELECT token FROM registrations WHERE event_id=@e AND student_id=(SELECT id FROM students WHERE university_id=@u)", ("@e", id), ("@u", u));
    return Results.Ok(new { token = row[0]["token"] });
});

app.MapGet("/api/my", (string uid) => Q(@"SELECT r.token,r.attended_at,e.title,e.location,e.starts_at
  FROM registrations r JOIN students s ON s.id=r.student_id JOIN events e ON e.id=r.event_id
  WHERE s.university_id=@u ORDER BY e.starts_at", ("@u", uid.Trim())));

app.MapGet("/api/certificate/{token}", IResult (string token) =>
{
    var r = Q(@"SELECT s.name,e.title,e.starts_at,c.name club FROM registrations r
      JOIN students s ON s.id=r.student_id JOIN events e ON e.id=r.event_id JOIN clubs c ON c.id=e.club_id
      WHERE r.token=@t AND r.attended_at IS NOT NULL", ("@t", token));
    return r.Count == 0 ? Results.NotFound(new { error = "لا توجد شهادة: لم يُسجَّل حضورك بعد" }) : Results.Ok(r[0]);
});

// ---------- المنظم (رمز دخول) ----------
app.MapGet("/api/organizer/verify", IResult (HttpRequest q) => Org(q) ? Results.Ok() : Results.Json(new { error = "رمز الدخول غير صحيح" }, statusCode: 401));
app.MapGet("/api/clubs", () => Q("SELECT id,name FROM clubs"));

app.MapGet("/api/organizer/events", IResult (HttpRequest q) => !Org(q) ? Results.Unauthorized() : Results.Ok(Q(@"
  SELECT e.id,e.title,e.starts_at,e.capacity,
   (SELECT COUNT(*) FROM registrations WHERE event_id=e.id) registered,
   (SELECT COUNT(*) FROM registrations WHERE event_id=e.id AND attended_at IS NOT NULL) attended
  FROM events e ORDER BY e.starts_at")));

app.MapGet("/api/organizer/events/{id:int}/attendees", IResult (HttpRequest q, int id) => !Org(q) ? Results.Unauthorized() : Results.Ok(Q(@"
  SELECT s.name,s.university_id,r.attended_at FROM registrations r JOIN students s ON s.id=r.student_id
  WHERE r.event_id=@e ORDER BY s.name", ("@e", id))));

app.MapPost("/api/organizer/events", IResult (HttpRequest q, Ev e) =>
{
    if (!Org(q)) return Results.Unauthorized();
    if (string.IsNullOrWhiteSpace(e.title)) return Results.BadRequest(new { error = "العنوان مطلوب" });
    X("INSERT INTO events(club_id,title,description,location,starts_at,capacity) VALUES(@c,@t,@d,@l,@s,@n)",
      ("@c", e.clubId), ("@t", e.title), ("@d", e.description), ("@l", e.location), ("@s", e.startsAt), ("@n", e.capacity > 0 ? e.capacity : 100));
    return Results.Ok();
});

app.MapPost("/api/organizer/checkin", IResult (HttpRequest q, Tok t) =>
{
    if (!Org(q)) return Results.Unauthorized();
    var r = Q(@"SELECT r.id,r.attended_at,s.name,e.title FROM registrations r
      JOIN students s ON s.id=r.student_id JOIN events e ON e.id=r.event_id WHERE r.token=@t", ("@t", (t.token ?? "").Trim().ToUpper()));
    if (r.Count == 0) return Results.NotFound(new { error = "رمز غير صالح" });
    if (r[0]["attended_at"] != null) return Results.Conflict(new { error = $"سُجّل حضور {r[0]["name"]} مسبقًا" });
    X("UPDATE registrations SET attended_at=datetime('now') WHERE id=@i", ("@i", r[0]["id"]));
    return Results.Ok(new { name = r[0]["name"], title = r[0]["title"] });
});

app.Run();

record Reg(string universityId, string name);
record Ev(int clubId, string title, string? description, string? location, string startsAt, int capacity);
record Tok(string? token);
