const $ = s => document.querySelector(s), app = $('#app');
let me = JSON.parse(localStorage.getItem('me') || 'null'), org = sessionStorage.getItem('org') || '', view = 'events', scanner = null, last = '';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = s => new Date(s.replace(' ', 'T') + (s.includes('T') ? '' : 'Z')).toLocaleString('ar-SA', {dateStyle: 'medium', timeStyle: 'short'});
const toast = m => { const t = $('#toast'); t.textContent = m; t.hidden = false; clearTimeout(t.h); t.h = setTimeout(() => t.hidden = true, 2800); };
async function api(p, o = {}) {
  let r; try { r = await fetch('/api' + p, {...o, headers: {'Content-Type': 'application/json', 'X-Code': org}, body: o.body && JSON.stringify(o.body)}); } catch { throw new Error('لا يوجد اتصال بالخادم. شغّل dotnet run وافتح العنوان الذي يظهر في الطرفية (لا تفتح index.html مباشرة).'); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || ('حدث خطأ (' + r.status + ') في ' + p));
  return d;
}
document.querySelectorAll('nav button').forEach(b => b.onclick = () => go(b.dataset.v));
function go(v) {
  view = v; stopScan();
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  Promise.resolve().then(({events: pageEvents, tickets: pageTickets, org: pageOrg})[v])
    .catch(e => { app.innerHTML = `<div class="card"><b>تعذّر فتح الصفحة</b><p class="meta" dir="ltr">${esc(e.message)}</p><p>تأكد أن الخادم يعمل (dotnet run) ثم حدّث الصفحة بـ Ctrl+Shift+R.</p></div>`; });
}

// ---------- الطالب ----------
async function pageEvents() {
  const ev = await api('/events');
  app.innerHTML = `<div class="card">${me
    ? `<div class="row"><span>مرحبًا <b>${esc(me.name)}</b> (${esc(me.uid)})</span><button class="s" id="chg">تغيير الهوية</button></div>`
    : `<b>عرّف بنفسك للتسجيل (بدون كلمة مرور)</b><div class="f" style="margin-top:8px"><input id="nm" placeholder="الاسم"><input id="uid" placeholder="الرقم الجامعي" inputmode="numeric"><button class="p" id="sv">حفظ</button></div>`}</div>`
    + ev.map(e => `<div class="card"><div class="row"><div><h3>${esc(e.title)}</h3><div class="meta">${esc(e.club)} — ${esc(e.location)} — ${fmt(e.starts_at)}</div></div>
      <button class="p" data-id="${e.id}" ${e.registered >= e.capacity ? 'disabled' : ''}>${e.registered >= e.capacity ? 'اكتمل العدد' : 'سجّل حضورك'}</button></div>
      <p>${esc(e.description)}</p><div class="meta">المسجلون: ${e.registered} / ${e.capacity}</div></div>`).join('');
  if ($('#sv')) $('#sv').onclick = () => {
    const name = $('#nm').value.trim(), uid = $('#uid').value.trim();
    if (!name || !uid) return toast('أدخل الاسم والرقم الجامعي');
    me = {name, uid}; localStorage.setItem('me', JSON.stringify(me)); pageEvents();
  };
  if ($('#chg')) $('#chg').onclick = () => { localStorage.removeItem('me'); me = null; pageEvents(); };
  app.querySelectorAll('button[data-id]').forEach(b => b.onclick = async () => {
    if (!me) return toast('احفظ اسمك ورقمك الجامعي أولًا');
    try { await api(`/events/${b.dataset.id}/register`, {method: 'POST', body: {name: me.name, universityId: me.uid}}); toast('تم التسجيل — تذكرتك في «تذاكري»'); pageEvents(); }
    catch (e) { toast(e.message); }
  });
}
async function pageTickets() {
  if (!me) { app.innerHTML = '<div class="card">سجّل هويتك من صفحة الفعاليات أولًا.</div>'; return; }
  const t = await api('/my?uid=' + encodeURIComponent(me.uid));
  app.innerHTML = t.length ? t.map(x => `<div class="card"><h3>${esc(x.title)}</h3><div class="meta">${esc(x.location)} — ${fmt(x.starts_at)}</div>
    ${x.attended_at ? `<p class="ok">✔ تم تسجيل حضورك</p><button class="p" data-c="${x.token}">تحميل الشهادة (PDF)</button>`
      : `<div class="qr" data-q="${x.token}"></div><div class="meta">أظهر الرمز للمنظم عند الدخول: ${x.token}</div>`}</div>`).join('')
    : '<div class="card">لا توجد تذاكر بعد. سجّل في فعالية من صفحة الفعاليات.</div>';
  app.querySelectorAll('[data-q]').forEach(d => new QRCode(d, {text: d.dataset.q, width: 160, height: 160}));
  app.querySelectorAll('[data-c]').forEach(b => b.onclick = () => cert(b.dataset.c));
}
async function cert(tok) {
  try {
    const c = await api('/certificate/' + tok), w = open('', '_blank');
    w.document.write(`<html dir="rtl" lang="ar"><meta charset="utf-8"><title>شهادة حضور</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;800&display=swap">
<style>@page{size:A4 landscape;margin:0}body{margin:0;font-family:Tajawal,sans-serif;display:grid;place-items:center;height:100vh;color:#14231D}
.b{border:12px double #4C1D95;padding:50px 80px;text-align:center;width:78%}h1{color:#4C1D95;font-size:48px;margin:0 0 20px}h2{color:#7C3AED;font-size:38px;margin:10px 0}</style>
<div class="b"><h1>شهادة حضور</h1><p>تشهد ${esc(c.club)} بأن</p><h2>${esc(c.name)}</h2><p>قد حضر فعالية «${esc(c.title)}»</p><p>${fmt(c.starts_at)}</p></div>
<script>onload=()=>setTimeout(print,400)<\/script></html>`);
    w.document.close();
  } catch (e) { toast(e.message); }
}

// ---------- المنظم ----------
async function pageOrg() {
  try { await api('/organizer/verify'); }
  catch {
    app.innerHTML = `<div class="card"><b>دخول المنظم</b><div class="f" style="margin-top:8px"><input id="code" type="password" placeholder="رمز الدخول"><button class="p" id="go">دخول</button></div></div>`;
    $('#go').onclick = () => { org = $('#code').value.trim(); sessionStorage.setItem('org', org); pageOrg(); };
    return;
  }
  const [ev, clubs] = await Promise.all([api('/organizer/events'), api('/clubs')]);
  app.innerHTML = `<div class="card"><h3>مسح تذكرة الحضور</h3><div id="reader" style="max-width:320px"></div>
    <div class="f"><button class="p" id="scan">تشغيل الكاميرا</button><input id="man" placeholder="أو أدخل رمز التذكرة يدويًا"><button class="s" id="mc">تسجيل</button></div></div>
    <div class="card"><h3>الفعاليات والحضور</h3><div style="overflow-x:auto"><table><tr><th>الفعالية</th><th>المسجلون</th><th>الحاضرون</th><th></th></tr>
    ${ev.map(e => `<tr><td>${esc(e.title)}</td><td>${e.registered}/${e.capacity}</td><td>${e.attended}</td><td><button class="s" data-a="${e.id}">القائمة</button></td></tr>`).join('')}</table></div><div id="att"></div></div>
    <div class="card"><h3>فعالية جديدة</h3><div class="f"><select id="cl">${clubs.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
    <input id="ti" placeholder="العنوان"><input id="lo" placeholder="المكان"><input id="dt" type="datetime-local"><input id="cp" type="number" placeholder="السعة" value="100"></div>
    <input id="ds" placeholder="الوصف" style="margin-bottom:10px"><button class="p" id="mk">نشر الفعالية</button> <button class="s" id="out">خروج</button></div>`;
  $('#scan').onclick = startScan;
  $('#mc').onclick = () => checkin($('#man').value);
  $('#out').onclick = () => { org = ''; sessionStorage.removeItem('org'); pageOrg(); };
  $('#mk').onclick = async () => {
    try { await api('/organizer/events', {method: 'POST', body: {clubId: +$('#cl').value, title: $('#ti').value, description: $('#ds').value, location: $('#lo').value, startsAt: $('#dt').value.replace('T', ' '), capacity: +$('#cp').value}}); toast('تم نشر الفعالية'); pageOrg(); }
    catch (e) { toast(e.message); }
  };
  app.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
    const a = await api(`/organizer/events/${b.dataset.a}/attendees`);
    $('#att').innerHTML = a.length ? `<table>${a.map(x => `<tr><td>${esc(x.name)}</td><td>${esc(x.university_id)}</td><td>${x.attended_at ? '<span class="ok">حاضر</span>' : 'لم يحضر'}</td></tr>`).join('')}</table>` : '<p class="meta">لا يوجد مسجلون بعد.</p>';
  });
}
function startScan() {
  stopScan(); scanner = new Html5Qrcode('reader');
  scanner.start({facingMode: 'environment'}, {fps: 10, qrbox: 220}, t => checkin(t), () => {}).catch(() => toast('تعذّر فتح الكاميرا، استخدم الإدخال اليدوي'));
}
function stopScan() { if (scanner) { scanner.stop().catch(() => {}); scanner = null; } }
async function checkin(t) {
  t = (t || '').trim(); if (!t || t === last) return; last = t; setTimeout(() => last = '', 3000);
  try { const d = await api('/organizer/checkin', {method: 'POST', body: {token: t}}); toast('✔ تم تسجيل حضور ' + d.name); }
  catch (e) { toast(e.message); }
}
go('events');
